<%@page import="java.sql.*"%>
<%@ page language="java" contentType="text/html; charset=EUC-KR" pageEncoding="EUC-KR" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.-1 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=EUC-KR">
    <link href="/css/sign_up_style.css" rel="stylesheet" type="text/css">
    <title>Sign_up</title>
</head>
<script
        src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
        crossorigin="anonymous"></script>
<script>
    function checkemail(str)    {
        var useremail = str;
        var reg_email = /^([0-9a-zA-Z_\.-]+)@([0-9a-zA-Z_-]+)(\.[0-9a-zA-Z_-]+){1,2}$/;
        if(reg_email.test(str)) {
            // $.ajax({
            //     url : "/users",
            //     type:"GET",
            //     data : {useremail},
            //     success:function(){
            //         return 2;
            //     },
            //     error: function (){
            //         return 1;
            //     }
            // })
            return 1;
        }
        else
            return 3;
    }
    function checkpassword(str) {
        var reg_pwd = /^(?=.*?[a-z])(?=.*?[0-9]).{8,}$/;
        if(reg_pwd.test(str))
            return true;
        else
            return false;
    }

    function confirmpassword(str1, str2) {
        if(str1 ==str2)
            return true;
        else
            return false;
    }

    $(document).ready(function() {
        $('#sign_up').click(function() {
            var useremail = $('#useremail').val();
            var userpassword = $('#userpassword').val();
            var repassword = $('#repassword').val();
            if(checkemail(useremail)==1) {   //�̸��� ���� üũ
                if(checkpassword(userpassword)) { //��й�ȣ ���� üũ
                    if(confirmpassword(userpassword, repassword)) {
                        $.ajax({
                            url : "/insert",
                            type:"GET",
                            data : {useremail, userpassword},   //json���� ������ > { "useremail": useremail, "userpwd": userpassword} db�̸��� ��ġ��Ű��
                            success:function(){
                                alert("ȸ�������� �Ϸ�ƽ��ϴ�.^^");
                                location.href = "/"
                            },
                            error: function (){
                                alert("err");
                            }
                        })
                    }
                    else
                        alert('��й�ȣ�� ���� �ٸ��ϴ�.');
                }
                else
                    alert('��й�ȣ�� 8�� �̻��̾�� �ϸ�, ����/�ҹ��ڸ� �����ؾ� �մϴ�.');
            }
            else if(checkemail(useremail)==2)
                alert('�ߺ��� �̸��� �ּ��Դϴ�.');
            else
                alert('�߸��� �̸��� �����Դϴ�.');
        })
    })
</script>
<body>
<div class="container">
    <div class="main">
        <div class="title">
            <img id="title" src="/css/img/sign_up.png" alt="" />
        </div>
        <div class="input">
            <input type="text" id="useremail" placeholder="Email"/> <br>
            <input type="password" id="userpassword" placeholder="Password" title="���� �ҹ��ڿ� ���ڸ� �����Ͽ� 8�� �̻��̾�� �մϴ�."/> <br>
            <input type="password" id="repassword" placeholder="Confirm Password"/>
        </div>
        <button id="sign_up">�����ϱ�</button>
    </div>
</div>
</body>
</html>